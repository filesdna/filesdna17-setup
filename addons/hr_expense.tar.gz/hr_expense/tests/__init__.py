# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_account_journal_dashboard
from . import test_expenses
from . import test_expenses_access_rights
from . import test_expenses_mail_import
from . import test_expenses_multi_company
from . import test_expenses_tax
from . import test_expenses_standard_price_update_warning
from . import test_expenses_states
from . import test_ui
from . import test_expenses_tour
